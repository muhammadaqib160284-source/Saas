"use client";

import { useEffect, useRef } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/**
 * A soft radial glow that trails the pointer across the whole page.
 * Purely decorative and inert to input (pointer-events-none), so it
 * never interferes with hit-testing or causes layout shifts.
 * Skipped on touch devices and when reduced motion is requested.
 */
export default function CursorGlow() {
  const mouseX = useMotionValue(-400);
  const mouseY = useMotionValue(-400);
  const x = useSpring(mouseX, { damping: 40, stiffness: 120, mass: 0.6 });
  const y = useSpring(mouseY, { damping: 40, stiffness: 120, mass: 0.6 });
  const enabled = useRef(true);

  useEffect(() => {
    const isTouch = window.matchMedia("(pointer: coarse)").matches;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    enabled.current = !isTouch && !reducedMotion;
    if (!enabled.current) return;

    const handleMove = (e: PointerEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
    };
    window.addEventListener("pointermove", handleMove);
    return () => window.removeEventListener("pointermove", handleMove);
  }, [mouseX, mouseY]);

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none fixed left-0 top-0 z-[1] hidden h-[520px] w-[520px] rounded-full mix-blend-screen md:block"
      style={{
        x,
        y,
        translateX: "-50%",
        translateY: "-50%",
        background:
          "radial-gradient(circle, rgba(180,243,74,0.10) 0%, rgba(20,184,166,0.06) 45%, transparent 70%)",
      }}
    />
  );
}
