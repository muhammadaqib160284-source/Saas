"use client";

import { useEffect, useRef } from "react";
import { gsap, ScrollTrigger, registerGsap } from "@/lib/gsap";

interface UseCounterOptions {
  end: number;
  duration?: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
}

/**
 * Animates the count from 0 to `end` once the bound element scrolls
 * into view. The element must already render the final value server-side
 * (via its initial text content) so there is no layout shift and the
 * number is present for SEO/no-JS users; this hook only rewrites the
 * text content once mounted.
 */
export function useCounter<T extends HTMLElement>({
  end,
  duration = 1.8,
  decimals = 0,
  prefix = "",
  suffix = "",
}: UseCounterOptions) {
  const ref = useRef<T | null>(null);

  useEffect(() => {
    registerGsap();
    const el = ref.current;
    if (!el) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const counter = { value: 0 };

    const format = (v: number) => `${prefix}${v.toFixed(decimals)}${suffix}`;

    if (prefersReducedMotion) {
      el.textContent = format(end);
      return;
    }

    const tween = gsap.to(counter, {
      value: end,
      duration,
      ease: "power2.out",
      onUpdate: () => {
        el.textContent = format(counter.value);
      },
      scrollTrigger: {
        trigger: el,
        start: "top 88%",
        once: true,
      },
    });

    return () => {
      tween.kill();
    };
  }, [end, duration, decimals, prefix, suffix]);

  return ref;
}
