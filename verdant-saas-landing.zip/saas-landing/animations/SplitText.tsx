"use client";

import { useRef } from "react";
import { useIsomorphicLayoutEffect } from "@/hooks/useIsomorphicLayoutEffect";
import { gsap, ScrollTrigger, registerGsap } from "@/lib/gsap";
import { cn } from "@/lib/utils";

interface SplitTextProps {
  children: string;
  as?: "h1" | "h2" | "h3" | "p" | "span";
  className?: string;
  /** "words" reveals whole words (good for long copy), "chars" reveals letters (good for short headlines). */
  splitBy?: "words" | "chars";
  /** Trigger on scroll into view instead of immediately on mount. */
  scrollTrigger?: boolean;
  delay?: number;
  stagger?: number;
}

/**
 * Renders real, crawlable text in the DOM (good for SEO/accessibility),
 * then progressively enhances it with a GSAP stagger reveal split into
 * words or characters. The wrapping spans reserve the same box the plain
 * text would occupy, so there is no layout shift before hydration.
 */
export default function SplitText({
  children,
  as: Tag = "h2",
  className,
  splitBy = "words",
  scrollTrigger = true,
  delay = 0,
  stagger = 0.035,
}: SplitTextProps) {
  const containerRef = useRef<HTMLElement | null>(null);

  useIsomorphicLayoutEffect(() => {
    registerGsap();
    const el = containerRef.current;
    if (!el) return;

    const ctx = gsap.context(() => {
      const targets = el.querySelectorAll<HTMLElement>("[data-split-unit]");

      gsap.set(targets, { yPercent: 115, opacity: 0 });

      const tween = gsap.to(targets, {
        yPercent: 0,
        opacity: 1,
        duration: 0.9,
        ease: "power4.out",
        stagger,
        delay,
        scrollTrigger: scrollTrigger
          ? {
              trigger: el,
              start: "top 85%",
              once: true,
            }
          : undefined,
      });

      return () => {
        tween.kill();
      };
    }, containerRef);

    return () => ctx.revert();
  }, [children, splitBy, scrollTrigger, delay, stagger]);

  const units = splitBy === "chars" ? Array.from(children) : children.split(" ");

  return (
    <Tag ref={containerRef as never} className={cn("[perspective:1000px]", className)}>
      <span aria-hidden="true">
        {units.map((unit, i) => (
          <span key={`${unit}-${i}`} className="inline-block overflow-hidden align-top">
            <span data-split-unit className="inline-block will-change-transform">
              {unit === " " ? "\u00A0" : unit}
              {splitBy === "words" && i < units.length - 1 ? "\u00A0" : ""}
            </span>
          </span>
        ))}
      </span>
      <span className="sr-only">{children}</span>
    </Tag>
  );
}
