import type { LucideIcon } from "lucide-react";
import {
  Activity,
  Layers,
  ShieldCheck,
  Sparkles,
  Workflow,
  Gauge,
  GitBranch,
  Radar,
  Boxes,
  Zap,
} from "lucide-react";

export const siteConfig = {
  name: "Verdant",
  tagline: "The signal layer for modern finance teams.",
  description:
    "Verdant turns raw transaction data into a live, explainable signal your team can act on in seconds — not sprints.",
};

export const navLinks = [
  { label: "Product", href: "#product" },
  { label: "Features", href: "#features" },
  { label: "Pricing", href: "#pricing" },
  { label: "Customers", href: "#testimonials" },
  { label: "FAQ", href: "#faq" },
];

export const trustedCompanies = [
  "Northwind Capital",
  "Ledgerline",
  "Aurora Pay",
  "Fathom Bank",
  "Silvertide",
  "Marlow & Co",
];

export interface Feature {
  icon: LucideIcon;
  title: string;
  description: string;
}

export const features: Feature[] = [
  {
    icon: Activity,
    title: "Live signal engine",
    description:
      "Every transaction is scored the instant it lands, so anomalies surface in under 400ms instead of next quarter's audit.",
  },
  {
    icon: Workflow,
    title: "Composable workflows",
    description:
      "Chain models, rules, and human review into a single pipeline you can version, test, and roll back like code.",
  },
  {
    icon: ShieldCheck,
    title: "Bank-grade compliance",
    description:
      "SOC 2 Type II, encrypted at rest and in transit, with a full audit trail on every decision the system makes.",
  },
  {
    icon: Layers,
    title: "Unified data layer",
    description:
      "Bring ledgers, card networks, and open banking feeds into one schema without writing a single ETL job.",
  },
  {
    icon: Radar,
    title: "Anomaly radar",
    description:
      "Self-tuning thresholds learn your baseline and quiet the noise, so alerts stay rare, ranked, and worth opening.",
  },
  {
    icon: Boxes,
    title: "Modular by design",
    description:
      "Turn capabilities on per team or product line. Start with monitoring, add automation when you're ready.",
  },
];

export interface Stat {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  label: string;
}

export const stats: Stat[] = [
  { value: 412, suffix: "ms", label: "Median signal latency" },
  { value: 99.98, decimals: 2, suffix: "%", label: "Platform uptime" },
  { value: 2.4, decimals: 1, prefix: "$", suffix: "B+", label: "Transactions monitored monthly" },
  { value: 63, suffix: "%", label: "Fewer false-positive alerts" },
];

export interface WorkflowStep {
  index: string;
  title: string;
  description: string;
  icon: LucideIcon;
}

export const workflowSteps: WorkflowStep[] = [
  {
    index: "01",
    title: "Ingest every source",
    description:
      "Connect ledgers, card processors, and banking APIs. Verdant normalizes them into one live event stream.",
    icon: GitBranch,
  },
  {
    index: "02",
    title: "Score in real time",
    description:
      "Ensemble models built on your historical data assign a risk and opportunity score to every event as it arrives.",
    icon: Gauge,
  },
  {
    index: "03",
    title: "Route intelligently",
    description:
      "High-confidence cases resolve automatically. Ambiguous ones route to the right reviewer with full context attached.",
    icon: Workflow,
  },
  {
    index: "04",
    title: "Learn from outcomes",
    description:
      "Every human decision feeds back into the model, so the signal gets sharper — and quieter — every single week.",
    icon: Sparkles,
  },
];

export interface PricingPlan {
  name: string;
  price: string;
  cadence: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  cta: string;
}

export const pricingPlans: PricingPlan[] = [
  {
    name: "Starter",
    price: "$0",
    cadence: "/mo",
    description: "For small teams validating their first live signal.",
    features: [
      "Up to 10k events / month",
      "1 connected data source",
      "Community support",
      "7-day event history",
    ],
    cta: "Start for free",
  },
  {
    name: "Growth",
    price: "$249",
    cadence: "/mo",
    description: "For teams operationalizing monitoring across products.",
    features: [
      "Up to 2M events / month",
      "Unlimited data sources",
      "Priority support & Slack channel",
      "1-year event history",
      "Custom workflow builder",
    ],
    highlighted: true,
    cta: "Start free trial",
  },
  {
    name: "Enterprise",
    price: "Custom",
    cadence: "",
    description: "For institutions with dedicated compliance needs.",
    features: [
      "Unlimited events",
      "Dedicated infrastructure",
      "SSO, SCIM & audit exports",
      "Custom data retention",
      "Solutions engineer on call",
    ],
    cta: "Talk to sales",
  },
];

export interface Testimonial {
  quote: string;
  name: string;
  role: string;
  company: string;
}

export const testimonials: Testimonial[] = [
  {
    quote:
      "We went from reviewing alerts in batches every morning to catching drift the moment it starts. Our fraud team finally works ahead of the problem instead of behind it.",
    name: "Priya Nandan",
    role: "Head of Risk",
    company: "Fathom Bank",
  },
  {
    quote:
      "Verdant replaced four brittle internal scripts with one workflow we can actually maintain. Onboarding a new data source now takes an afternoon, not a quarter.",
    name: "Marcus Aldridge",
    role: "VP Engineering",
    company: "Ledgerline",
  },
  {
    quote:
      "The explainability view is what sold our compliance team. Every score comes with a reason a human can actually defend in an audit.",
    name: "Elena Cho",
    role: "Chief Compliance Officer",
    company: "Silvertide",
  },
  {
    quote:
      "False positives dropped by more than half in the first month. That alone paid for the platform three times over.",
    name: "Tobias Renner",
    role: "Director of Operations",
    company: "Aurora Pay",
  },
];

export interface FaqItem {
  question: string;
  answer: string;
}

export const faqItems: FaqItem[] = [
  {
    question: "How long does implementation take?",
    answer:
      "Most teams connect their first data source and see live signal within a day. A full multi-source rollout with custom workflows typically takes two to three weeks alongside our solutions team.",
  },
  {
    question: "Can Verdant fit our existing review process?",
    answer:
      "Yes. Verdant routes ambiguous cases into the tools your team already uses — Slack, Jira, or your internal case manager — rather than forcing everyone into a new interface.",
  },
  {
    question: "What happens to our data?",
    answer:
      "All data is encrypted in transit and at rest, isolated per tenant, and never used to train models for other customers. You can export or delete your history at any time.",
  },
  {
    question: "Do you support on-premise or VPC deployment?",
    answer:
      "Enterprise plans support dedicated single-tenant infrastructure and can deploy into your own VPC. Talk to our sales team about your specific compliance requirements.",
  },
  {
    question: "How does pricing scale with usage?",
    answer:
      "Plans are priced by monthly event volume, not by seat, so you can add reviewers without your bill changing. You'll get a heads-up well before you approach your plan's limit.",
  },
];
