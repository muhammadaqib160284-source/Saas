"use client";

import { useEffect, useState } from "react";
import { motion, useMotionValueEvent, useScroll, AnimatePresence } from "framer-motion";
import { Menu, X, ArrowUpRight } from "lucide-react";
import Button from "@/components/ui/Button";
import { navLinks, siteConfig } from "@/data/content";
import { navReveal } from "@/animations/variants";
import { useLenis } from "@/animations/SmoothScrollProvider";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const lenis = useLenis();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 24);
  });

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const handleNavClick = (href: string) => {
    setOpen(false);
    const target = document.querySelector(href);
    if (target instanceof HTMLElement) {
      if (lenis) lenis.scrollTo(target, { offset: -24 });
      else target.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <motion.header
      initial="hidden"
      animate="visible"
      variants={navReveal}
      className="fixed inset-x-0 top-0 z-50"
    >
      <div className="container-px mx-auto max-w-7xl pt-4">
        <div
          className={cn(
            "flex items-center justify-between rounded-full border px-4 py-2.5 transition-all duration-500 sm:px-5",
            scrolled
              ? "border-white/10 bg-void/70 shadow-card backdrop-blur-xl"
              : "border-transparent bg-transparent",
          )}
        >
          <a href="#top" className="flex items-center gap-2 font-display text-lg font-semibold tracking-tight text-ink">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-signal-gradient text-xs font-bold text-void">
              V
            </span>
            {siteConfig.name}
          </a>

          <nav aria-label="Primary" className="hidden items-center gap-8 md:flex">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="text-sm text-ink-muted transition-colors hover:text-ink"
              >
                {link.label}
              </button>
            ))}
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            <Button variant="ghost" size="md" onClick={() => handleNavClick("#pricing")}>
              Sign in
            </Button>
            <Button variant="primary" size="md" onClick={() => handleNavClick("#pricing")} icon={<ArrowUpRight className="h-4 w-4" />}>
              Get started
            </Button>
          </div>

          <button
            className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-ink md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="container-px mx-auto mt-2 max-w-7xl md:hidden"
          >
            <div className="glass-card flex flex-col gap-1 p-4">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="rounded-lg px-3 py-3 text-left text-sm text-ink-muted transition-colors hover:bg-white/[0.04] hover:text-ink"
                >
                  {link.label}
                </button>
              ))}
              <div className="mt-2 flex flex-col gap-2 border-t border-white/[0.06] pt-3">
                <Button variant="secondary" onClick={() => handleNavClick("#pricing")}>
                  Sign in
                </Button>
                <Button variant="primary" onClick={() => handleNavClick("#pricing")}>
                  Get started
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
