"use client";

import { motion } from "framer-motion";
import { Twitter, Github, Linkedin } from "lucide-react";
import PulseWave from "@/components/ui/PulseWave";
import { siteConfig } from "@/data/content";
import { fadeUp, staggerContainer, viewportOnce } from "@/animations/variants";

const columns = [
  {
    title: "Product",
    links: ["Overview", "Features", "Pricing", "Changelog"],
  },
  {
    title: "Company",
    links: ["About", "Careers", "Blog", "Press"],
  },
  {
    title: "Resources",
    links: ["Documentation", "API reference", "Status", "Security"],
  },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-white/[0.06] pb-10 pt-20">
      <div className="container-px mx-auto max-w-7xl">
        <div className="mb-16 opacity-60">
          <PulseWave className="h-10" />
        </div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          variants={staggerContainer(0.08)}
          className="grid grid-cols-2 gap-10 sm:grid-cols-4 lg:grid-cols-5"
        >
          <motion.div variants={fadeUp} className="col-span-2 flex flex-col gap-4 lg:col-span-2">
            <a href="#top" className="flex items-center gap-2 font-display text-lg font-semibold text-ink">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-signal-gradient text-xs font-bold text-void">
                V
              </span>
              {siteConfig.name}
            </a>
            <p className="max-w-xs text-sm text-ink-muted">{siteConfig.description}</p>
            <div className="mt-2 flex items-center gap-3">
              {[Twitter, Github, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social link"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-ink-muted transition-colors hover:border-lime-400/40 hover:text-lime-300"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </motion.div>

          {columns.map((col) => (
            <motion.div key={col.title} variants={fadeUp} className="flex flex-col gap-4">
              <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-ink-faint">{col.title}</h4>
              <ul className="flex flex-col gap-3">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-ink-muted transition-colors hover:text-ink">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-8 sm:flex-row">
          <p className="text-xs text-ink-faint">
            &copy; {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <div className="flex gap-6 text-xs text-ink-faint">
            <a href="#" className="hover:text-ink-muted">
              Privacy
            </a>
            <a href="#" className="hover:text-ink-muted">
              Terms
            </a>
            <a href="#" className="hover:text-ink-muted">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
