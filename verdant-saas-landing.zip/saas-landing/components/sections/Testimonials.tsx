"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import { testimonials } from "@/data/content";
import { EASE_OUT } from "@/animations/variants";

export default function Testimonials() {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const go = useCallback((next: number) => {
    setDirection(next > index ? 1 : -1);
    setIndex((next + testimonials.length) % testimonials.length);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) return;

    timerRef.current = setInterval(() => {
      setDirection(1);
      setIndex((i) => (i + 1) % testimonials.length);
    }, 6500);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const current = testimonials[index];

  return (
    <section id="testimonials" className="relative py-28 sm:py-36">
      <div className="container-px mx-auto max-w-4xl">
        <SectionHeading
          eyebrow="Customers"
          title="Teams who used to react are now ahead of the signal"
        />

        <div className="relative mt-16">
          <div className="glass-card relative min-h-[280px] overflow-hidden p-8 sm:p-12">
            <Quote className="h-8 w-8 text-lime-400/40" aria-hidden="true" />
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={current?.name}
                custom={direction}
                initial={{ opacity: 0, x: direction * 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: direction * -40 }}
                transition={{ duration: 0.5, ease: EASE_OUT }}
                className="mt-4 flex flex-col gap-6"
              >
                <p className="text-balance font-display text-xl font-medium leading-relaxed text-ink sm:text-2xl">
                  &ldquo;{current?.quote}&rdquo;
                </p>
                <div className="flex flex-col">
                  <span className="font-medium text-ink">{current?.name}</span>
                  <span className="text-sm text-ink-muted">
                    {current?.role}, {current?.company}
                  </span>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="mt-8 flex items-center justify-center gap-6">
            <button
              onClick={() => go(index - 1)}
              aria-label="Previous testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-ink-muted transition-colors hover:border-lime-400/40 hover:text-ink"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>

            <div className="flex items-center gap-2">
              {testimonials.map((t, i) => (
                <button
                  key={t.name}
                  onClick={() => go(i)}
                  aria-label={`Go to testimonial from ${t.name}`}
                  aria-current={i === index}
                  className={`h-1.5 rounded-full transition-all duration-500 ${
                    i === index ? "w-8 bg-lime-400" : "w-1.5 bg-white/15"
                  }`}
                />
              ))}
            </div>

            <button
              onClick={() => go(index + 1)}
              aria-label="Next testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-ink-muted transition-colors hover:border-lime-400/40 hover:text-ink"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
