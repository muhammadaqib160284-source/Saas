"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, PlayCircle } from "lucide-react";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import GradientOrb from "@/components/ui/GradientOrb";
import GridBackground from "@/components/ui/GridBackground";
import ParticleField from "@/components/ui/ParticleField";
import DashboardMockup from "@/components/ui/DashboardMockup";
import SplitText from "@/animations/SplitText";
import { fadeUp, staggerContainer, viewportOnce } from "@/animations/variants";
import { trustedCompanies } from "@/data/content";

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pb-24 pt-40 sm:pt-48">
      <GridBackground className="opacity-70" />
      <ParticleField count={22} className="opacity-80" />
      <GradientOrb className="left-[-10%] top-[-10%]" size={620} from="rgba(52,226,160,0.32)" />
      <GradientOrb
        className="right-[-15%] top-[20%]"
        size={520}
        from="rgba(180,243,74,0.28)"
        to="rgba(20,184,166,0.08)"
        duration={11}
        delay={1.5}
      />

      <div className="container-px relative z-10 mx-auto max-w-7xl">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={staggerContainer(0.12, 0.1)}
          className="mx-auto flex max-w-3xl flex-col items-center gap-7 text-center"
        >
          <motion.div variants={fadeUp}>
            <Badge>Now live: real-time signal API</Badge>
          </motion.div>

          <SplitText
            as="h1"
            splitBy="words"
            scrollTrigger={false}
            delay={0.15}
            className="text-display-xl font-display font-semibold text-ink"
          >
            The signal layer for modern finance teams.
          </SplitText>

          <motion.p variants={fadeUp} className="max-w-xl text-balance text-base text-ink-muted sm:text-lg">
            Verdant turns raw transaction data into a live, explainable signal your team can act
            on in seconds — not sprints. Built for risk, compliance, and ops teams who can&rsquo;t
            afford to be last to know.
          </motion.p>

          <motion.div variants={fadeUp} className="flex flex-col items-center gap-4 sm:flex-row">
            <Button variant="primary" size="lg" href="#pricing" icon={<ArrowUpRight className="h-4 w-4" />}>
              Start for free
            </Button>
            <Button variant="secondary" size="lg" href="#product" icon={<PlayCircle className="h-4 w-4" />}>
              Watch product tour
            </Button>
          </motion.div>

          <motion.p variants={fadeUp} className="font-mono text-xs uppercase tracking-[0.2em] text-ink-faint">
            No credit card &middot; Live in under 5 minutes
          </motion.p>
        </motion.div>

        <div className="mt-20">
          <DashboardMockup />
        </div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          variants={staggerContainer(0.06, 0.1)}
          className="mt-24 flex flex-col items-center gap-6"
        >
          <motion.p variants={fadeUp} className="font-mono text-xs uppercase tracking-[0.2em] text-ink-faint">
            Trusted by finance teams at
          </motion.p>
          <motion.ul
            variants={fadeUp}
            className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4 opacity-70 grayscale"
          >
            {trustedCompanies.map((name) => (
              <li key={name} className="font-display text-lg font-medium text-ink-muted">
                {name}
              </li>
            ))}
          </motion.ul>
        </motion.div>
      </div>
    </section>
  );
}
