"use client";

import { useRef } from "react";
import { useIsomorphicLayoutEffect } from "@/hooks/useIsomorphicLayoutEffect";
import { gsap, ScrollTrigger, registerGsap } from "@/lib/gsap";
import SectionHeading from "@/components/ui/SectionHeading";
import { workflowSteps } from "@/data/content";

export default function WorkflowTimeline() {
  const sectionRef = useRef<HTMLElement | null>(null);
  const lineRef = useRef<HTMLDivElement | null>(null);

  useIsomorphicLayoutEffect(() => {
    registerGsap();
    const section = sectionRef.current;
    const line = lineRef.current;
    if (!section || !line) return;

    const ctx = gsap.context(() => {
      gsap.set(line, { scaleY: 0, transformOrigin: "top center" });

      gsap.to(line, {
        scaleY: 1,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top 70%",
          end: "bottom 60%",
          scrub: 0.6,
        },
      });

      const items = gsap.utils.toArray<HTMLElement>("[data-timeline-item]");
      items.forEach((item) => {
        gsap.fromTo(
          item,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
              trigger: item,
              start: "top 82%",
              once: true,
            },
          },
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section className="relative py-28 sm:py-36">
      <div className="container-px mx-auto max-w-5xl">
        <SectionHeading
          eyebrow="Workflow"
          title="From raw event to resolved case in four steps"
          description="A typed pipeline your engineering team can read, test, and extend — not a black box."
        />

        <div ref={sectionRef} className="relative mt-20">
          <div
            aria-hidden="true"
            className="absolute left-[27px] top-2 h-[calc(100%-1rem)] w-px bg-white/[0.08] sm:left-[31px]"
          >
            <div
              ref={lineRef}
              className="h-full w-full bg-gradient-to-b from-emerald-400 via-teal-400 to-lime-400"
            />
          </div>

          <ol className="flex flex-col gap-14">
            {workflowSteps.map((step) => {
              const Icon = step.icon;
              return (
                <li key={step.index} data-timeline-item className="relative flex gap-6 pl-0 will-change-transform">
                  <span className="relative z-10 flex h-14 w-14 flex-none items-center justify-center rounded-2xl border border-lime-400/25 bg-void-surface shadow-glow sm:h-16 sm:w-16">
                    <Icon className="h-6 w-6 text-lime-300" aria-hidden="true" />
                  </span>
                  <div className="flex flex-col gap-2 pt-1">
                    <span className="font-mono text-xs uppercase tracking-[0.25em] text-ink-faint">
                      Step {step.index}
                    </span>
                    <h3 className="font-display text-xl font-semibold text-ink sm:text-2xl">{step.title}</h3>
                    <p className="max-w-xl text-ink-muted">{step.description}</p>
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
