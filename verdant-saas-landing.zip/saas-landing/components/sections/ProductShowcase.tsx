"use client";

import { useRef, useState } from "react";
import { useIsomorphicLayoutEffect } from "@/hooks/useIsomorphicLayoutEffect";
import { gsap, ScrollTrigger, registerGsap } from "@/lib/gsap";
import { Activity, Radar, Workflow } from "lucide-react";
import Badge from "@/components/ui/Badge";
import PulseWave from "@/components/ui/PulseWave";

const panels = [
  {
    label: "Monitor",
    icon: Activity,
    title: "Watch every transaction as it happens",
    description:
      "A single live feed replaces a dozen disconnected dashboards, normalized across every connected source.",
    metric: { label: "Events / sec", value: "12,480" },
  },
  {
    label: "Detect",
    icon: Radar,
    title: "Catch drift before it becomes a headline",
    description:
      "Self-tuning thresholds adapt to your baseline, so the system flags what's actually unusual — not just unfamiliar.",
    metric: { label: "Anomalies today", value: "37" },
  },
  {
    label: "Automate",
    icon: Workflow,
    title: "Resolve the routine, route the rest",
    description:
      "High-confidence cases close themselves. Everything else lands with your reviewers, fully annotated.",
    metric: { label: "Auto-resolved", value: "94%" },
  },
];

export default function ProductShowcase() {
  const sectionRef = useRef<HTMLElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [active, setActive] = useState(0);

  useIsomorphicLayoutEffect(() => {
    registerGsap();
    const section = sectionRef.current;
    const stage = stageRef.current;
    if (!section || !stage) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const ctx = gsap.context(() => {
      const steps = gsap.utils.toArray<HTMLElement>("[data-step]");
      if (prefersReducedMotion || steps.length === 0) return;

      const mm = gsap.matchMedia();

      mm.add("(min-width: 1024px)", () => {
        const st = ScrollTrigger.create({
          trigger: section,
          start: "top top",
          end: () => `+=${steps.length * 520}`,
          pin: stage,
          pinSpacing: false,
          scrub: false,
        });

        return () => st.kill();
      });

      steps.forEach((step, i) => {
        ScrollTrigger.create({
          trigger: step,
          start: "top center",
          end: "bottom center",
          onEnter: () => setActive(i),
          onEnterBack: () => setActive(i),
        });
      });

      return () => mm.revert();
    }, section);

    return () => ctx.revert();
  }, []);

  const ActiveIcon = panels[active]?.icon ?? Activity;

  return (
    <section id="product" ref={sectionRef} className="relative py-28 sm:py-36">
      <div className="container-px mx-auto max-w-7xl">
        <div className="mx-auto mb-16 flex max-w-2xl flex-col items-center gap-5 text-center">
          <span className="eyebrow">Product</span>
          <h2 className="text-display-md font-display font-semibold text-ink">
            One workspace, from first event to final decision
          </h2>
          <p className="text-base text-ink-muted sm:text-lg">
            Scroll through a real Verdant session — the same pipeline every customer runs in
            production.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          {/* Scroll-synced step copy */}
          <div className="flex flex-col gap-24 lg:gap-40">
            {panels.map((panel, i) => {
              const Icon = panel.icon;
              return (
                <div
                  key={panel.label}
                  data-step
                  className="flex flex-col gap-4 lg:min-h-[40vh] lg:justify-center"
                >
                  <span className="font-mono text-xs uppercase tracking-[0.25em] text-ink-faint">
                    Step {i + 1} of {panels.length}
                  </span>
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.03]">
                    <Icon className="h-5 w-5 text-lime-300" aria-hidden="true" />
                  </span>
                  <h3 className="font-display text-2xl font-semibold text-ink sm:text-3xl">{panel.title}</h3>
                  <p className="max-w-md text-ink-muted">{panel.description}</p>
                </div>
              );
            })}
          </div>

          {/* Pinned visual stage */}
          <div ref={stageRef} className="lg:h-screen lg:py-[10vh]">
            <div className="glass-card relative mx-auto flex h-full max-h-[520px] w-full max-w-lg flex-col overflow-hidden p-8">
              <div aria-hidden="true" className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime-400/60 to-transparent" />

              <div className="flex items-center justify-between border-b border-white/[0.06] pb-4">
                <Badge>{panels[active]?.label}</Badge>
                <ActiveIcon className="h-5 w-5 text-ink-faint" aria-hidden="true" />
              </div>

              <div className="flex flex-1 flex-col justify-center gap-6">
                <PulseWave className="h-20" key={active} />
                <div className="flex items-end justify-between">
                  <div>
                    <p className="font-mono text-xs uppercase tracking-widest text-ink-faint">
                      {panels[active]?.metric.label}
                    </p>
                    <p className="font-display text-4xl font-semibold text-ink">
                      {panels[active]?.metric.value}
                    </p>
                  </div>
                  <div className="flex gap-1.5" aria-hidden="true">
                    {panels.map((_, i) => (
                      <span
                        key={i}
                        className={`h-1.5 rounded-full transition-all duration-500 ${
                          i === active ? "w-8 bg-lime-400" : "w-3 bg-white/15"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
