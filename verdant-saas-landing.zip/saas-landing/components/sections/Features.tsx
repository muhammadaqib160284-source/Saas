"use client";

import { motion } from "framer-motion";
import SectionHeading from "@/components/ui/SectionHeading";
import GlowCard from "@/components/ui/GlowCard";
import { fadeUp, staggerContainer, viewportOnce } from "@/animations/variants";
import { features } from "@/data/content";

export default function Features() {
  return (
    <section id="features" className="relative py-28 sm:py-36">
      <div className="container-px mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Platform"
          title="Everything your signal pipeline needs, in one place"
          description="Verdant replaces a stack of brittle scripts and dashboards with a single, composable platform your whole team can trust."
        />

        <motion.ul
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          variants={staggerContainer(0.1, 0.1)}
          className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <GlowCard key={feature.title} as="li">
                <motion.div variants={fadeUp} className="flex h-full flex-col gap-5">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/[0.08] bg-white/[0.03]">
                    <Icon className="h-5 w-5 text-lime-300" aria-hidden="true" />
                  </span>
                  <div className="flex flex-col gap-2">
                    <h3 className="font-display text-lg font-semibold text-ink">{feature.title}</h3>
                    <p className="text-sm leading-relaxed text-ink-muted">{feature.description}</p>
                  </div>
                </motion.div>
              </GlowCard>
            );
          })}
        </motion.ul>
      </div>
    </section>
  );
}
