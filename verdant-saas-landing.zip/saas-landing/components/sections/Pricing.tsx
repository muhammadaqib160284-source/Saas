"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import Button from "@/components/ui/Button";
import { fadeUp, scaleIn, staggerContainer, viewportOnce } from "@/animations/variants";
import { pricingPlans } from "@/data/content";
import { cn } from "@/lib/utils";

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-28 sm:py-36">
      <div className="container-px mx-auto max-w-7xl">
        <SectionHeading
          eyebrow="Pricing"
          title="Plans that scale with your event volume, not your headcount"
          description="Start free, upgrade when your signal needs grow. No seat-based pricing, ever."
        />

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          variants={staggerContainer(0.12, 0.1)}
          className="mt-16 grid grid-cols-1 items-stretch gap-6 lg:grid-cols-3"
        >
          {pricingPlans.map((plan) => (
            <motion.div
              key={plan.name}
              variants={plan.highlighted ? scaleIn : fadeUp}
              whileHover={{ y: -8 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className={cn(
                "glass-card relative flex flex-col gap-8 p-8",
                plan.highlighted && "border-lime-400/40 shadow-glow-lime lg:scale-[1.03]",
              )}
            >
              {plan.highlighted && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-signal-gradient px-4 py-1 font-mono text-[11px] uppercase tracking-widest text-void">
                  Most popular
                </span>
              )}

              <div className="flex flex-col gap-2">
                <h3 className="font-display text-xl font-semibold text-ink">{plan.name}</h3>
                <p className="text-sm text-ink-muted">{plan.description}</p>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="font-display text-4xl font-semibold text-ink">{plan.price}</span>
                <span className="text-sm text-ink-muted">{plan.cadence}</span>
              </div>

              <ul className="flex flex-1 flex-col gap-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5 text-sm text-ink-muted">
                    <Check className="mt-0.5 h-4 w-4 flex-none text-emerald-400" aria-hidden="true" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                variant={plan.highlighted ? "primary" : "secondary"}
                className="w-full justify-center"
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
