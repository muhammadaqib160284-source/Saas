"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import Button from "@/components/ui/Button";
import GradientOrb from "@/components/ui/GradientOrb";
import PulseWave from "@/components/ui/PulseWave";
import SplitText from "@/animations/SplitText";
import { fadeUp, staggerContainer, viewportOnce } from "@/animations/variants";

export default function FinalCTA() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container-px mx-auto max-w-5xl">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          variants={staggerContainer(0.12, 0.05)}
          className="glass-card relative flex flex-col items-center gap-8 overflow-hidden px-6 py-16 text-center sm:px-16"
        >
          <GradientOrb className="left-1/2 top-0 -translate-x-1/2" size={520} duration={10} />

          <motion.div variants={fadeUp} className="w-full max-w-md opacity-70">
            <PulseWave className="h-12" />
          </motion.div>

          <SplitText
            as="h2"
            splitBy="words"
            className="relative z-10 max-w-2xl text-display-md font-display font-semibold text-ink"
          >
            Give your team the signal before it becomes the story.
          </SplitText>

          <motion.p variants={fadeUp} className="relative z-10 max-w-lg text-ink-muted">
            Connect your first data source in minutes and see live, explainable risk scoring on
            your own transactions today.
          </motion.p>

          <motion.div variants={fadeUp} className="relative z-10 flex flex-col gap-4 sm:flex-row">
            <Button variant="primary" size="lg" href="#pricing" icon={<ArrowUpRight className="h-4 w-4" />}>
              Start for free
            </Button>
            <Button variant="secondary" size="lg" href="#faq">
              Talk to sales
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
