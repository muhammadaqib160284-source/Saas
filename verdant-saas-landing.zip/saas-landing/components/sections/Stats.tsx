"use client";

import { motion } from "framer-motion";
import { useCounter } from "@/animations/useCounter";
import { fadeUp, staggerContainer, viewportOnce } from "@/animations/variants";
import { stats, type Stat } from "@/data/content";

function StatItem({ stat }: { stat: Stat }) {
  const ref = useCounter<HTMLParagraphElement>({
    end: stat.value,
    decimals: stat.decimals ?? 0,
    prefix: stat.prefix ?? "",
    suffix: stat.suffix ?? "",
  });

  const formatted = `${stat.prefix ?? ""}${stat.value.toFixed(stat.decimals ?? 0)}${stat.suffix ?? ""}`;

  return (
    <motion.div variants={fadeUp} className="flex flex-col items-center gap-2 text-center sm:items-start sm:text-left">
      {/* Server-rendered final value for SEO/no-JS; the hook overwrites it client-side with a count-up. */}
      <p ref={ref} className="text-gradient-signal font-display text-4xl font-semibold sm:text-5xl">
        {formatted}
      </p>
      <p className="text-sm text-ink-muted">{stat.label}</p>
    </motion.div>
  );
}

export default function Stats() {
  return (
    <section className="relative border-y border-white/[0.06] bg-void-soft/40 py-20">
      <div className="container-px mx-auto max-w-7xl">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={viewportOnce}
          variants={staggerContainer(0.1)}
          className="grid grid-cols-2 gap-10 sm:grid-cols-4"
        >
          {stats.map((stat) => (
            <StatItem key={stat.label} stat={stat} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
