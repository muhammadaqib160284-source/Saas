"use client";

import { useRef, useState, type ReactNode, type MouseEvent } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { cn } from "@/lib/utils";

interface ButtonProps {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost";
  size?: "md" | "lg";
  className?: string;
  icon?: ReactNode;
  type?: "button" | "submit";
}

interface Ripple {
  id: number;
  x: number;
  y: number;
}

/**
 * Shared button used for every CTA on the page. Adds a magnetic pull
 * toward the cursor and a click ripple, both driven by transform/opacity
 * only (no layout properties) to stay GPU-accelerated and shift-free.
 */
export default function Button({
  children,
  href,
  onClick,
  variant = "primary",
  size = "md",
  className,
  icon,
  type = "button",
}: ButtonProps) {
  const ref = useRef<HTMLElement | null>(null);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: MouseEvent<HTMLElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relX = e.clientX - rect.left - rect.width / 2;
    const relY = e.clientY - rect.top - rect.height / 2;
    setPos({ x: relX * 0.25, y: relY * 0.35 });
  };

  const handleMouseLeave = () => setPos({ x: 0, y: 0 });

  const handleClick = (e: MouseEvent<HTMLElement>) => {
    const el = ref.current;
    if (el) {
      const rect = el.getBoundingClientRect();
      const id = Date.now();
      setRipples((prev) => [
        ...prev,
        { id, x: e.clientX - rect.left, y: e.clientY - rect.top },
      ]);
      window.setTimeout(() => {
        setRipples((prev) => prev.filter((r) => r.id !== id));
      }, 650);
    }
    onClick?.();
  };

  const base =
    "relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full font-medium transition-colors duration-300 select-none";
  const sizes = {
    md: "px-6 py-3 text-sm",
    lg: "px-8 py-4 text-base",
  };
  const variants = {
    primary:
      "bg-signal-gradient text-void shadow-glow hover:shadow-glow-lime",
    secondary:
      "border border-white/15 bg-white/[0.04] text-ink backdrop-blur-md hover:border-lime-400/40 hover:bg-white/[0.08]",
    ghost: "text-ink-muted hover:text-ink",
  };

  const content = (
    <>
      <span className="relative z-10 flex items-center gap-2">
        {children}
        {icon}
      </span>
      {ripples.map((r) => (
        <motion.span
          key={r.id}
          initial={{ width: 0, height: 0, opacity: 0.5 }}
          animate={{ width: 260, height: 260, opacity: 0 }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="pointer-events-none absolute rounded-full bg-white/40"
          style={{ left: r.x, top: r.y, translateX: "-50%", translateY: "-50%" }}
        />
      ))}
    </>
  );

  const motionProps = {
    animate: { x: pos.x, y: pos.y },
    transition: { type: "spring" as const, stiffness: 200, damping: 18, mass: 0.4 },
    onMouseMove: handleMouseMove,
    onMouseLeave: handleMouseLeave,
    onClick: handleClick,
    className: cn(base, sizes[size], variants[variant], className),
  };

  if (href) {
    return (
      <motion.span ref={ref as never} {...motionProps} className={cn(motionProps.className, "cursor-pointer")}>
        <Link href={href} className="absolute inset-0 z-20" aria-label={typeof children === "string" ? children : undefined} />
        {content}
      </motion.span>
    );
  }

  return (
    <motion.button ref={ref as never} type={type} {...motionProps}>
      {content}
    </motion.button>
  );
}
