import { cn } from "@/lib/utils";

export default function GridBackground({ className }: { className?: string }) {
  return (
    <div
      aria-hidden="true"
      className={cn("pointer-events-none absolute inset-0 grid-bg motion-safe:animate-[float_16s_ease-in-out_infinite]", className)}
    />
  );
}
