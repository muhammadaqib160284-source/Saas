"use client";

import { motion } from "framer-motion";
import { Activity, ArrowUpRight, ShieldCheck } from "lucide-react";
import PulseWave from "./PulseWave";
import { fadeUp, staggerContainer, viewportOnce } from "@/animations/variants";

const bars = [38, 62, 44, 80, 56, 70, 48, 90, 65, 74, 52, 84];

export default function DashboardMockup() {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={viewportOnce}
      variants={staggerContainer(0.15, 0.2)}
      className="relative mx-auto w-full max-w-xl"
    >
      {/* Floating status chip */}
      <motion.div
        variants={fadeUp}
        className="glass-card absolute -left-6 -top-6 z-20 hidden items-center gap-2 px-4 py-2.5 sm:flex motion-safe:animate-float"
      >
        <ShieldCheck className="h-4 w-4 text-emerald-400" aria-hidden="true" />
        <span className="text-xs font-medium text-ink">Risk cleared &middot; 214ms</span>
      </motion.div>

      <motion.div
        variants={fadeUp}
        className="glass-card absolute -bottom-8 -right-4 z-20 hidden w-48 flex-col gap-1 px-4 py-3 sm:flex motion-safe:animate-float"
        style={{ animationDelay: "1.2s" }}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs text-ink-muted">Signal score</span>
          <ArrowUpRight className="h-3.5 w-3.5 text-lime-400" aria-hidden="true" />
        </div>
        <span className="font-display text-2xl font-semibold text-gradient-signal">98.4</span>
      </motion.div>

      {/* Main panel */}
      <motion.div variants={fadeUp} className="glass-card relative overflow-hidden p-6 sm:p-8">
        <div aria-hidden="true" className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-lime-400/60 to-transparent" />

        <div className="flex items-center justify-between border-b border-white/[0.06] pb-4">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_2px_rgba(52,226,160,0.6)] motion-safe:animate-pulse-soft" />
            <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">Live signal &middot; Production</span>
          </div>
          <Activity className="h-4 w-4 text-ink-faint" aria-hidden="true" />
        </div>

        <div className="mt-6">
          <PulseWave className="h-16" />
        </div>

        <div className="mt-4 flex h-28 items-end gap-1.5" aria-hidden="true">
          {bars.map((h, i) => (
            <motion.div
              key={i}
              initial={{ height: 0 }}
              whileInView={{ height: `${h}%` }}
              viewport={viewportOnce}
              transition={{ duration: 0.8, delay: 0.4 + i * 0.04, ease: [0.16, 1, 0.3, 1] }}
              className="w-full rounded-t-sm bg-gradient-to-t from-emerald-500/40 to-lime-400/80"
            />
          ))}
        </div>
        <div className="grid w-full grid-cols-3 gap-4 border-t border-white/[0.06] pt-4 text-left">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-widest text-ink-faint">Events</p>
            <p className="font-display text-lg font-semibold text-ink">1.8M</p>
          </div>
          <div>
            <p className="font-mono text-[11px] uppercase tracking-widest text-ink-faint">Flagged</p>
            <p className="font-display text-lg font-semibold text-ink">0.3%</p>
          </div>
          <div>
            <p className="font-mono text-[11px] uppercase tracking-widest text-ink-faint">Latency</p>
            <p className="font-display text-lg font-semibold text-ink">412ms</p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
