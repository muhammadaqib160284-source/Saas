import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export default function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-lime-400/20 bg-lime-400/[0.06] px-4 py-1.5 font-mono text-xs uppercase tracking-[0.2em] text-lime-300",
        className,
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-lime-400 shadow-[0_0_8px_2px_rgba(180,243,74,0.6)] motion-safe:animate-pulse-soft" />
      {children}
    </span>
  );
}
