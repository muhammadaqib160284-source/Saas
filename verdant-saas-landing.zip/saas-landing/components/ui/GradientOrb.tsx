"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface GradientOrbProps {
  className?: string;
  from?: string;
  to?: string;
  size?: number;
  duration?: number;
  delay?: number;
}

/**
 * A large, heavily-blurred radial blob. Animates only transform/opacity
 * (via Framer Motion) so it stays cheap even with several on screen.
 */
export default function GradientOrb({
  className,
  from = "rgba(52,226,160,0.35)",
  to = "rgba(180,243,74,0.12)",
  size = 560,
  duration = 9,
  delay = 0,
}: GradientOrbProps) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn("pointer-events-none absolute rounded-full blur-[110px] will-change-transform", className)}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle at 30% 30%, ${from}, ${to} 60%, transparent 75%)`,
      }}
      animate={{
        y: [0, -30, 0],
        x: [0, 18, 0],
        scale: [1, 1.06, 1],
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    />
  );
}
