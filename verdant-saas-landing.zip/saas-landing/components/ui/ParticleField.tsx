"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface Particle {
  id: number;
  left: string;
  top: string;
  size: number;
  duration: number;
  delay: number;
  opacity: number;
}

function makeParticles(count: number): Particle[] {
  return Array.from({ length: count }).map((_, i) => ({
    id: i,
    left: `${Math.round(Math.random() * 100)}%`,
    top: `${Math.round(Math.random() * 100)}%`,
    size: Math.random() * 2.5 + 1,
    duration: Math.random() * 6 + 6,
    delay: Math.random() * 5,
    opacity: Math.random() * 0.5 + 0.25,
  }));
}

/**
 * A small constellation of soft glowing dots that drift slowly.
 * Count stays intentionally low and motion is transform/opacity only,
 * so this stays cheap even layered behind other animated sections.
 */
export default function ParticleField({ count = 26, className }: { count?: number; className?: string }) {
  const [particles, setParticles] = useState<Particle[]>([]);

  // Generated only on the client so server and first client render match;
  // this field is purely decorative, so a mount-frame delay is invisible.
  useEffect(() => {
    setParticles(makeParticles(count));
  }, [count]);

  return (
    <div aria-hidden="true" className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}>
      {particles.map((p) => (
        <motion.span
          key={p.id}
          className="absolute rounded-full bg-lime-300 motion-reduce:hidden"
          style={{
            left: p.left,
            top: p.top,
            width: p.size,
            height: p.size,
            opacity: p.opacity,
            boxShadow: "0 0 8px 1px rgba(180,243,74,0.5)",
          }}
          animate={{ y: [0, -22, 0], opacity: [p.opacity, p.opacity * 1.6, p.opacity] }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}
