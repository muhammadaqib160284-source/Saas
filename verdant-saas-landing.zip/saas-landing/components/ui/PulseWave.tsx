"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface PulseWaveProps {
  className?: string;
  strokeClassName?: string;
}

/**
 * The site's signature motif: a live-looking signal line, echoing the
 * product's real-time monitoring pitch. Drawn once with a stroke-dashoffset
 * reveal, then loops a soft traveling highlight — both transform/opacity
 * driven, no layout impact.
 */
export default function PulseWave({ className, strokeClassName }: PulseWaveProps) {
  return (
    <svg
      viewBox="0 0 600 80"
      fill="none"
      className={cn("w-full overflow-visible", className)}
      aria-hidden="true"
    >
      <motion.path
        d="M0 40 H120 L145 10 L170 70 L195 25 L215 40 H320 L345 15 L370 65 L392 40 H600"
        stroke="url(#pulse-gradient)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={strokeClassName}
        initial={{ pathLength: 0, opacity: 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 1.6, ease: [0.16, 1, 0.3, 1] }}
      />
      <defs>
        <linearGradient id="pulse-gradient" x1="0" y1="0" x2="600" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#0A9268" stopOpacity="0" />
          <stop offset="20%" stopColor="#14B8A6" />
          <stop offset="55%" stopColor="#B4F34A" />
          <stop offset="100%" stopColor="#34E2A0" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
}
