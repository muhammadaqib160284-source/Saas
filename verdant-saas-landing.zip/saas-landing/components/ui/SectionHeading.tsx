import SplitText from "@/animations/SplitText";
import { cn } from "@/lib/utils";

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
}

export default function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
  className,
}: SectionHeadingProps) {
  return (
    <div className={cn("flex flex-col gap-5", align === "center" ? "items-center text-center" : "items-start text-left", className)}>
      <span className="eyebrow">{eyebrow}</span>
      <SplitText
        as="h2"
        splitBy="words"
        className={cn("text-display-md font-display font-semibold text-ink", align === "center" && "max-w-3xl")}
      >
        {title}
      </SplitText>
      {description && (
        <p className={cn("text-base text-ink-muted sm:text-lg", align === "center" ? "max-w-2xl" : "max-w-xl")}>
          {description}
        </p>
      )}
    </div>
  );
}
