"use client";

import { useRef, type MouseEvent, type ReactNode } from "react";
import { motion, useMotionTemplate, useMotionValue } from "framer-motion";
import { cn } from "@/lib/utils";

interface GlowCardProps {
  children: ReactNode;
  className?: string;
  as?: "div" | "li";
}

export default function GlowCard({ children, className, as = "div" }: GlowCardProps) {
  const ref = useRef<HTMLDivElement | null>(null);
  const mouseX = useMotionValue(50);
  const mouseY = useMotionValue(50);
  const background = useMotionTemplate`radial-gradient(280px circle at ${mouseX}% ${mouseY}%, rgba(180,243,74,0.14), transparent 70%)`;

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    mouseX.set(((e.clientX - rect.left) / rect.width) * 100);
    mouseY.set(((e.clientY - rect.top) / rect.height) * 100);
  };

  const Comp = as === "li" ? motion.li : motion.div;

  return (
    <Comp
      ref={ref as never}
      onMouseMove={handleMouseMove}
      initial="rest"
      whileHover="hover"
      animate="rest"
      className={cn("glass-card group relative overflow-hidden p-8", className)}
    >
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{ background }}
      />
      <motion.div
        aria-hidden="true"
        variants={{ rest: { opacity: 0 }, hover: { opacity: 1 } }}
        transition={{ duration: 0.4 }}
        className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-lime-400/30"
      />
      <motion.div
        variants={{ rest: { y: 0 }, hover: { y: -4 } }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10"
      >
        {children}
      </motion.div>
    </Comp>
  );
}
