"use client";

import { useEffect, useLayoutEffect } from "react";

/**
 * Resolves to useLayoutEffect in the browser (needed for GSAP setup that
 * must run before paint) and to useEffect during SSR, where
 * useLayoutEffect would otherwise log a harmless-but-noisy warning.
 */
export const useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;
